-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: nu_scheduling
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `class_session`
--

DROP TABLE IF EXISTS `class_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `class_session` (
  `session_id` int unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int unsigned NOT NULL,
  `section_id` int unsigned NOT NULL,
  `day_id` int unsigned NOT NULL,
  `time_slot_id` int unsigned NOT NULL,
  `professors_id` int unsigned NOT NULL,
  `room_id` int unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `class_session_section_id_foreign` (`section_id`),
  KEY `class_session_time_slot_id_foreign` (`time_slot_id`),
  KEY `class_session_room_id_foreign` (`room_id`),
  KEY `class_session_day_id_foreign` (`day_id`),
  KEY `class_session_course_id_foreign` (`course_id`),
  KEY `class_session_professors_id_foreign` (`professors_id`),
  CONSTRAINT `class_session_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`),
  CONSTRAINT `class_session_day_id_foreign` FOREIGN KEY (`day_id`) REFERENCES `days` (`day_id`),
  CONSTRAINT `class_session_professors_id_foreign` FOREIGN KEY (`professors_id`) REFERENCES `professors` (`professor_id`),
  CONSTRAINT `class_session_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`),
  CONSTRAINT `class_session_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`section_id`),
  CONSTRAINT `class_session_time_slot_id_foreign` FOREIGN KEY (`time_slot_id`) REFERENCES `time_slot` (`time_slot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_session`
--

LOCK TABLES `class_session` WRITE;
/*!40000 ALTER TABLE `class_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `class_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `course_id` int unsigned NOT NULL AUTO_INCREMENT,
  `course_code` varchar(20) NOT NULL,
  `course_name` varchar(225) NOT NULL,
  `unit_amount` int NOT NULL,
  `minutes` int NOT NULL,
  `course_type` enum('Lecture','LecLab') DEFAULT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'CCINCOMX','INTRODUCTION TO COMPUTING',3,400,'LecLab'),(2,'CCPRGG1X','FUNDAMENTALS OF PROGRAMMING',3,400,'LecLab'),(3,'CTINFMGL','INFORMATION MANAGEMENT',3,400,'LecLab'),(4,'CCDATRCL','DATA STRUCTURES AND ALGORITHMS',3,400,'LecLab'),(5,'CCSPEL1X','SPORTS ELECTIVE 1 ( E-GAMES DESIGN I )',3,400,'LecLab'),(6,'CCALCOML','ALGORITHMS AND COMPLEXITY',3,400,'LecLab'),(7,'CIWEBPRL','WEB PROGRAMMING',3,400,'LecLab'),(8,'CCHUCOIL','HUMAN-COMPUTER INTERACTION',3,400,'LecLab'),(9,'CIMUCOGL','MULTIMEDIA AND COMPUTER GRAPHICS',3,400,'LecLab'),(10,'CCTHES1L','THESIS 1',3,400,'LecLab'),(11,'CCPGLANL','PROGRAMMING LANGUAGES',3,400,'LecLab'),(12,'CCSELE1L','C.S. ELECTIVE 1',3,400,'LecLab'),(13,'CCDISTR1','DISCRETE STRUCTURES 1',3,400,'LecLab'),(14,'CCPRGG2X','INTERMEDIATE PROGRAMMING',3,400,'LecLab'),(15,'CCOMPORL','COMPUTER ARCHITECTURE AND ORGANIZATION',3,400,'LecLab'),(16,'CCDATSYL','DATABASE SYSTEMS',3,400,'LecLab'),(17,'CCSPEL2X','SPORTS ELECTIVE 2 ( E- GAMES DESIGN II )',3,400,'LecLab'),(18,'CCSFEN1L','SOFTWARE ENGINEERING 1',3,400,'LecLab'),(19,'CTINASSL','INFORMATION ASSURANCE AND SECURITY',3,400,'LecLab'),(20,'CCNETCOL','NETWORK AND COMMUNICATIONS',3,400,'LecLab'),(21,'CCCSINTX','INTERNSHIP (MIN. 162 HRS)',3,400,'LecLab'),(22,'CCSELE2L','C.S. ELECTIVE 2',3,400,'LecLab'),(23,'CCDISTR2','DISCRETE STRUCTURES 2',3,400,'LecLab'),(24,'CCOBJPGL','OBJECT-ORIENTED PROGRAMMING',3,400,'LecLab'),(25,'CCQUAMET','QUANTITATIVE METHODS',3,400,'LecLab'),(26,'CCOPSYSL','OPERATING SYSTEMS',3,400,'LecLab'),(27,'CCAUTOMA','AUTOMATA THEORY AND FORMAL LANGUAGES',3,400,'LecLab'),(28,'CTAPDEVL','APPLICATION DEVELOPMENT AND EMERGING TECHNOLOGY',3,400,'LecLab'),(29,'CCSFEN2L','SOFTWARE ENGINEERING 2',3,400,'LecLab'),(30,'CCTHES2L','THESIS 2',3,400,'LecLab'),(31,'CCSELE3L','C.S. ELECTIVE 3',3,400,'LecLab'),(32,'CTPRFISS','SOCIAL AND PROFESSIONAL ISSUES',3,240,'Lecture'),(33,'CCFUINSY','FUNDAMENTALS OF INFORMATION SYSTEMS',3,400,'LecLab'),(34,'CCORMACO','ORGANIZATION AND MANAGEMENT CONCEPTS',3,400,'LecLab'),(35,'CIENTARL','ENTERPRISE ARCHITECTURE',3,400,'LecLab'),(36,'BUPRDEMA','BUSINESS PROCESS MANAGEMENT',3,240,'Lecture'),(37,'ITINNETE','I.T. INFRASTRUCTURE AND NETWORK TECHNOLOGIES',3,400,'LecLab'),(38,'BAFINMAX','FINANCIAL MANAGEMENT',3,240,'Lecture'),(39,'CIEVBUPE','EVALUATION OF BUSINESS PERFORMANCE',3,240,'Lecture'),(40,'CISECDEL','E-COMMERCE AND DIGITAL ENTREPRENEURSHIP',3,240,'Lecture'),(41,'CTSYSADL','SYSTEMS ANALYSIS AND DESIGN',3,400,'LecLab'),(42,'CISPRMAL','I.S. PROJECT MANAGEMENT',3,400,'LecLab'),(43,'CISELE1L','I.S. ELECTIVE 1',3,400,'LecLab'),(44,'CISELE2L','I.S. ELECTIVE 2',3,400,'LecLab'),(45,'CAPROJ1L','CAPSTONE PROJECT 1',3,400,'LecLab'),(46,'ISSTMAAC','I.S. STRATEGY MANAGEMENT AND ACQUISITION',3,400,'LecLab'),(47,'CISELE3L','I.S. ELECTIVE 3',3,400,'LecLab'),(48,'CCISINTX','INTERNSHIP (486 HRS)',3,240,'Lecture'),(49,'CAPROJ2L','CAPSTONE PROJECT 2',3,400,'LecLab'),(50,'PRISINSY','PROFESSIONAL ISSUES IN INFORMATION SYSTEMS',3,240,'Lecture'),(51,'CISELE4L','I.S. ELECTIVE 4',3,400,'LecLab'),(52,'INTCOMC','INTRODUCTION TO COMPUTING FOR CS / IT',3,400,'LecLab'),(53,'PROGCON','Programming Concepts and Logic',3,400,'LecLab'),(54,'COMPORG','COMPUTER ORGANIZATION &amp; ARCHITECTURE',3,400,'LecLab'),(55,'INPROLA','INTRODUCTION TO PROGRAMMING &amp; THEORIES',3,400,'LecLab'),(56,'MANPRIN','MANAGEMENT PRINCIPLES',3,240,'Lecture'),(57,'DASTRUC','DATA STRUCTURES',3,400,'LecLab'),(58,'BUSPROS','Business Process',3,240,'Lecture'),(59,'DISCRET','DISCRETE MATH',3,240,'Lecture'),(61,'USERDES','UI/UX DESIGN AND PROGRAMMING',3,400,'LecLab'),(63,'DNETCOM','NETWORK SECURITY, STORAGE &amp; DATA COMMUNICATION',3,400,'LecLab'),(64,'OPESYST','OPERATING SYSTEMS',3,400,'LecLab'),(65,'DATAMA1','DATABASE MANAGEMENT 1',3,400,'LecLab'),(66,'QUAMET1','QUANTITATIVE METHODS 1',3,400,'LecLab'),(67,'RPASYST','RPA SYSTEMS',3,400,'LecLab'),(68,'INFOSEC','INFORMATION SECURITY',3,400,'LecLab'),(69,'WEBPROG','WEB PROGAMMING (for BSIT)',3,400,'LecLab'),(70,'MOBPROG','MOBILE PROGRAMMING',3,400,'LecLab'),(71,'DATAMA2','DATABASE MANAGEMENT 2 and ADMINISTRATION',3,400,'LecLab'),(72,'PEMBEDS','PROGRAMMING EMBEDDED SYSTEMS',3,400,'LecLab'),(73,'ELECTV1','ELECTIVE 1',3,400,'LecLab'),(74,'CLDCOMP','CLOUD COMPUTING &amp; VIRTUALIZATION',3,400,'LecLab'),(75,'EXCOMP1','EXTENSIVE COMPETENCY COMMUNICATION PROGRAM 1',3,400,'LecLab'),(76,'MNTSDEV','INTRODUCTION TO SYSTEMS AND DESIGN',3,400,'LecLab'),(77,'ELECTV2','ELECTIVE 2',3,400,'LecLab'),(78,'MSYADD1','SYSTEMS ANALYSIS &amp; DETAILED DESIGN',3,400,'LecLab'),(79,'ELECTV3','ELECTIVE 3',3,400,'LecLab'),(80,'ICTSRV1','ICT SERVICES MANAGEMENT (A+ PC TROUBLESHOOTING)',3,400,'LecLab'),(81,'MCSPROJ','APPLIED PROJECT - SYSTEM PHOTOTYPE',3,400,'LecLab'),(82,'TENTREP','TECHNOPRENEURSHIP',3,240,'Lecture'),(83,'ELECTV4','ELECTIVE 4',3,400,'LecLab'),(84,'PROJMAN','PROJECT MANAGEMENT',3,400,'LecLab'),(85,'MNSYSIT','MANAGEMENT INFORMATION SYSTEMS &amp; IT TRENDS',3,400,'LecLab'),(86,'ITBLAWS','IT AND BUSINESS LAWS',3,240,'Lecture'),(87,'PROFETH','PROFESSIONAL ETHICS',3,240,'Lecture'),(88,'SOFTDEV','SOFTWARE DEVELOPMENT',3,400,'LecLab'),(89,'QUALITY','SOFTWARE QUALITY MANAGEMENT',3,400,'LecLab'),(90,'xINTERN1','INTERNSHIP 1',3,240,'Lecture'),(91,'INTERN2','INTERNSHIP 2',3,240,'Lecture');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `curriculum`
--

DROP TABLE IF EXISTS `curriculum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `curriculum` (
  `curriculum_id` int unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int unsigned NOT NULL,
  `program_id` int unsigned NOT NULL,
  `year_level_id` int unsigned NOT NULL,
  `term` int NOT NULL,
  PRIMARY KEY (`curriculum_id`),
  KEY `curriculum_course_id_foreign` (`course_id`),
  KEY `curriculum_program_id_foreign` (`program_id`),
  KEY `curriculum_year_level_id_foreign` (`year_level_id`),
  CONSTRAINT `curriculum_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`),
  CONSTRAINT `curriculum_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`),
  CONSTRAINT `curriculum_year_level_id_foreign` FOREIGN KEY (`year_level_id`) REFERENCES `year_level` (`year_level_id`),
  CONSTRAINT `chk_term` CHECK (((`term` >= 1) and (`term` <= 4)))
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `curriculum`
--

LOCK TABLES `curriculum` WRITE;
/*!40000 ALTER TABLE `curriculum` DISABLE KEYS */;
INSERT INTO `curriculum` VALUES (1,1,1,1,1),(2,1,3,1,1),(3,2,1,1,1),(4,2,3,1,1),(5,3,1,1,1),(6,3,3,1,1),(7,4,1,1,1),(8,4,3,1,1),(9,5,1,2,1),(10,5,3,2,1),(11,6,1,3,1),(12,7,1,3,1),(13,7,3,3,1),(14,8,1,3,1),(15,9,1,3,1),(16,9,3,3,1),(17,10,1,4,1),(18,11,1,4,1),(19,12,1,4,1),(20,13,1,1,2),(21,14,1,1,2),(22,14,3,1,2),(23,15,1,2,2),(24,16,1,2,2),(25,16,3,2,2),(26,17,1,2,2),(27,17,3,2,2),(28,18,1,3,2),(29,18,3,3,2),(30,19,1,3,2),(31,20,1,3,2),(32,21,1,4,2),(33,22,1,4,2),(34,23,1,1,3),(35,24,1,1,3),(36,25,1,2,3),(37,25,3,2,3),(38,26,1,2,3),(39,26,2,2,3),(40,27,1,3,3),(41,28,1,3,3),(42,28,3,3,3),(43,29,1,3,3),(44,30,1,4,3),(45,31,1,4,3),(46,32,1,4,3),(47,33,3,1,2),(48,34,3,1,3),(49,35,3,2,2),(50,36,3,2,2),(51,37,3,2,3),(52,38,3,3,1),(53,39,3,3,1),(54,40,3,3,2),(55,41,3,3,2),(56,42,3,3,2),(57,43,3,3,2),(58,44,3,3,3),(59,45,3,4,1),(60,46,3,4,1),(61,47,3,4,1),(62,48,3,4,2),(63,49,3,4,3),(64,50,3,4,3),(65,51,3,4,3),(66,52,2,1,1),(67,53,2,1,1),(68,54,2,1,1),(69,55,2,1,2),(70,56,2,1,2),(71,57,2,1,3),(72,58,2,1,3),(73,59,2,1,3),(75,61,2,2,1),(77,63,2,1,3),(78,64,2,1,2),(79,65,2,2,1),(80,66,2,2,1),(81,67,2,2,1),(82,68,2,2,1),(83,69,2,2,2),(84,70,2,2,2),(85,71,2,2,2),(86,72,2,2,2),(87,73,2,2,2),(88,74,2,2,2),(89,75,2,2,3),(90,76,2,2,3),(91,77,2,2,3),(92,78,2,3,1),(93,79,2,3,1),(94,80,2,3,1),(95,81,2,3,2),(96,82,2,3,2),(97,83,2,3,2),(98,84,2,3,3),(99,85,2,3,3),(100,86,2,3,3),(101,87,2,4,1),(102,88,2,4,1),(103,89,2,4,1),(104,90,2,4,2),(105,91,2,4,3);
/*!40000 ALTER TABLE `curriculum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `days`
--

DROP TABLE IF EXISTS `days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `days` (
  `day_id` int unsigned NOT NULL AUTO_INCREMENT,
  `day_name` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') NOT NULL,
  `day_type` enum('Weekday','Weekend') NOT NULL,
  PRIMARY KEY (`day_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `days`
--

LOCK TABLES `days` WRITE;
/*!40000 ALTER TABLE `days` DISABLE KEYS */;
/*!40000 ALTER TABLE `days` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professors`
--

DROP TABLE IF EXISTS `professors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `professors` (
  `professor_id` int unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `work_type` enum('Full-time','Part-time') NOT NULL,
  `hours_id` int unsigned NOT NULL,
  PRIMARY KEY (`professor_id`),
  KEY `professors_hours_id_foreign` (`hours_id`),
  CONSTRAINT `professors_hours_id_foreign` FOREIGN KEY (`hours_id`) REFERENCES `work_hours` (`hours_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professors`
--

LOCK TABLES `professors` WRITE;
/*!40000 ALTER TABLE `professors` DISABLE KEYS */;
/*!40000 ALTER TABLE `professors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programs` (
  `program_id` int unsigned NOT NULL AUTO_INCREMENT,
  `program_name` varchar(50) NOT NULL,
  PRIMARY KEY (`program_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES (1,'BSCS'),(2,'BSIT'),(3,'BSIS');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rooms` (
  `room_id` int unsigned NOT NULL AUTO_INCREMENT,
  `room_name` varchar(25) NOT NULL,
  `available_hours` int NOT NULL,
  `room_type` enum('Lecture','Laboratory') NOT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `section_id` int unsigned NOT NULL AUTO_INCREMENT,
  `program_id` int unsigned NOT NULL,
  `year_level_id` int unsigned NOT NULL,
  `alphabet` char(1) NOT NULL,
  PRIMARY KEY (`section_id`),
  KEY `sections_program_id_foreign` (`program_id`),
  KEY `sections_year_level_id_foreign` (`year_level_id`),
  CONSTRAINT `sections_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`),
  CONSTRAINT `sections_year_level_id_foreign` FOREIGN KEY (`year_level_id`) REFERENCES `year_level` (`year_level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_count`
--

DROP TABLE IF EXISTS `student_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_count` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `program_id` int unsigned NOT NULL,
  `year_level_id` int unsigned NOT NULL,
  `student_count` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `student_count_program_id_foreign` (`program_id`),
  KEY `student_count_year_level_id_foreign` (`year_level_id`),
  CONSTRAINT `student_count_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`),
  CONSTRAINT `student_count_year_level_id_foreign` FOREIGN KEY (`year_level_id`) REFERENCES `year_level` (`year_level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_count`
--

LOCK TABLES `student_count` WRITE;
/*!40000 ALTER TABLE `student_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_slot`
--

DROP TABLE IF EXISTS `time_slot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_slot` (
  `time_slot_id` int unsigned NOT NULL AUTO_INCREMENT,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `total_minutes` int NOT NULL,
  PRIMARY KEY (`time_slot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_slot`
--

LOCK TABLES `time_slot` WRITE;
/*!40000 ALTER TABLE `time_slot` DISABLE KEYS */;
/*!40000 ALTER TABLE `time_slot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_hours`
--

DROP TABLE IF EXISTS `work_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_hours` (
  `hours_id` int unsigned NOT NULL AUTO_INCREMENT,
  `number_of_hours` int NOT NULL,
  PRIMARY KEY (`hours_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_hours`
--

LOCK TABLES `work_hours` WRITE;
/*!40000 ALTER TABLE `work_hours` DISABLE KEYS */;
/*!40000 ALTER TABLE `work_hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `year_level`
--

DROP TABLE IF EXISTS `year_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `year_level` (
  `year_level_id` int unsigned NOT NULL AUTO_INCREMENT,
  `year_level` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`year_level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `year_level`
--

LOCK TABLES `year_level` WRITE;
/*!40000 ALTER TABLE `year_level` DISABLE KEYS */;
INSERT INTO `year_level` VALUES (1,'1st Year'),(2,'2nd Year'),(3,'3rd Year'),(4,'4th Year');
/*!40000 ALTER TABLE `year_level` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-18 16:02:31
